import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'labtwopointone';
  info =''
  uid: Number
  uname=''
  usal:Number
  udep=''
  ind=0
  emp = [
    {empId:1001,empName:"Rahul",empSal:9000,empDep:"Java"},
    {empId:1002,empName:"Sachin",empSal:19000,empDep:"OraApps"},
    {empId:1003,empName:"Vikash",empSal:29000,empDep:"BI"},
  ];
  addToTable(data){
    this.emp.push({empId:data.id1, empName:data.n1, empSal:data.sal1, empDep:data.dept1})
    this.info='Data inserted'
  }
  update(index){
    this.ind=index
    this.uid=this.emp[index].empId
    this.uname=this.emp[index].empName
    this.usal=this.emp[index].empSal
    this.udep=this.emp[index].empDep
  }
  updateTable(data1){
    var pos=this.ind;
	  if(data1.id2!=undefined){
	    this.emp[pos].empId=data1.id2
	  }
    if(data1.n2!=undefined){
      this.emp[pos].empName=data1.n2
    }
    if(data1.sal2!=undefined){
      this.emp[pos].empSal=data1.sal2
    }
    if(data1.dept2!=undefined){
      this.emp[pos].empDep=data1.dept2
    }
    this.info='Data updated'
  }
  deleteTable(index){
    this.emp.splice(index,1)
    this.info='Data deleted'
  }
}