import { Component } from '@angular/core';
import { BookService } from './book.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'labfourpointtwo';
  books = [];
  searchcols=["","","",""];
  constructor(private _service:BookService){

  }
  ngOnInit(){
    this._service.getBooks().subscribe((data)=>{
      this.books=data;
    });
  }
}

export interface Book{
  id: number,
  title:string,
  year:number,
  author:string
}