import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search',
  pure: false
})
export class SearchPipe implements PipeTransform {

  transform(books:any, search:any): any {
    if(search[0]){
      return books.filter(function(book:any){return book.id.toString().includes(search[0]);})
    }
    else if(search[1]){
      return books.filter(function(book:any){return book.title.toLowerCase().includes(search[1].toLowerCase());})
    }
    else if(search[2]){
      return books.filter(function(book:any){return book.year.toString().includes(search[2]);})
    }
    else if(search[3]){
      return books.filter(function(book:any){return book.author.toLowerCase().includes(search[3].toLowerCase());})
    }
    else
      return books;
  }
}
