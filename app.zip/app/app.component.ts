import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'first';
  info =''
  uid: Number
  uname=''
  usal:Number
  udep=''
  emp = [
    {empId:1001,empName:"Rahul",empSal:9000,empDep:"Java"},
    {empId:1002,empName:"Sachin",empSal:19000,empDep:"OraApps"},
    {empId:1003,empName:"Vikash",empSal:29000,empDep:"BI"},
  ];
  addToTable(data){
    this.emp.push({empId:data.id1, empName:data.n1, empSal:data.sal1, empDep:data.dept1})
    this.info='Data inserted'
  }
  update(employee){
    this.uid=employee.empId
    this.uname=employee.empName
    this.usal=employee.empSal
    this.udep=employee.empDep
  }
  updateTable(data1){
    var pos=0;
    for (var i=0; i < this.emp.length; i++) {
      if (this.emp[i].empId == this.uid) {
          pos=i;
      }
    }
    this.emp[pos].empId=data1.id2
    if(data1.n2!=undefined){
      this.emp[pos].empName=data1.n2
    }
    if(data1.sal2!=undefined){
      this.emp[pos].empSal=data1.sal2
    }
    if(data1.dept2!=undefined){
      this.emp[pos].empDep=data1.dept2
    }
    this.info='Data updated'
  }
  deleteTable(index){
    this.emp.splice(index,1)
    this.info='Data deleted'
  }
}