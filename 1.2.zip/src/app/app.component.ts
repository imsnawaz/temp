import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'my-app',
  templateUrl: `./app.component.html`,
})
export class AppComponent  { 
  alertme(data: any){
    alert(data.id+" "+data.name+" "+data.salary+" "+data.department)  
  }
 }
