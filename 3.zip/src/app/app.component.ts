import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'labthree';
  angForm : FormGroup;
  constructor (private fb: FormBuilder){
    this.createForm()
  }
  createForm(){
    this.angForm = this.fb.group({
      pid : ['', Validators.required],
      pname : ['', Validators.required],
      pcost : ['', Validators.required],
      isonline: ['', Validators.required],
      ptype: [],
      isavailable1: [],
      isavailable2: [],
      isavailable3:[],
      isavailable4:[]     
    });
  }
  printConsole(data){
    console.log(data)
  }
}
