import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search',
  pure: false
})
export class SearchPipe implements PipeTransform {

  transform(books:any, search:any): any {
    if(search[0]){
      books= books.filter(function(book:any){return book.id.toString().includes(search[0]);})
    }
    if(search[1]){
      books= books.filter(function(book:any){return book.title.toLowerCase().includes(search[1].toLowerCase());})
    }
    if(search[2]){
      books= books.filter(function(book:any){return book.year.toString().includes(search[2]);})
    }
    if(search[3]){
      books= books.filter(function(book:any){return book.author.toLowerCase().includes(search[3].toLowerCase());})
    }
    return books;
  }
}
