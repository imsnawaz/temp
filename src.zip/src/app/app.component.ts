import { Component } from '@angular/core';
import { BookService } from './book.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'test';
  books = [];
  search=["","","",""];
  ind:number;
  showuform=false;
  tronstart=true;
  trafterinit=false;
  showsearch:Boolean[]=[false,false,false,false];
  showbtns:Boolean[]=[true,true,true,true];
  eval:number;
  showentry(ele:number){
    this.eval=ele;
    this.tronstart=false;
    this.trafterinit=true;
    this.showsearch[this.eval]=true;
  }
  extend(){
    this.showsearch[this.eval]=false;
    this.showbtns[this.eval]=false;
    this.tronstart=true;
    this.trafterinit=false;
  }
  resetVals(){
    this.showsearch=[false,false,false,false];
    this.showbtns=[true,true,true,true];
    this.search=["","","",""];
    this.tronstart=true;
    this.trafterinit=false;
  }
  sortId(){
    this.books.sort(function(a, b){return a.id - b.id});
  }
  sortTitle(){
    this.books.sort(function(a, b){
      var x = a.title.toLowerCase();
      var y = b.title.toLowerCase();
      if (x < y) {return -1;}
      if (x > y) {return 1;}
      return 0;
    });
  }
  sortYear(){
    this.books.sort(function(a, b){return parseInt(a.year) - parseInt(b.year)});
  }
  sortAuthor(){
    this.books.sort(function(a, b){
      var x = a.author.toLowerCase();
      var y = b.author.toLowerCase();
      if (x < y) {return -1;}
      if (x > y) {return 1;}
      return 0;
    });
  }
  update(obj){
    this.showuform=true;
    this.ind=this.books.indexOf(obj)
  }
  deleteTable(obj){
    this.books.splice(this.books.indexOf(obj),1)
  }
  constructor(private _service:BookService){

  }
  ngOnInit(){
    this._service.getBooks().subscribe((data)=>{
      this.books=data;
    });
  }
}

export interface Book{
  id: number,
  title:string,
  year:number,
  author:string
}