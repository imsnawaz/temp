"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var basic_service_1 = require("./basic.service");
var smart_service_1 = require("./smart.service");
var AppComponent = (function () {
    function AppComponent(_service1, _service2) {
        this._service1 = _service1;
        this._service2 = _service2;
        this.mobiles = [
            { mobileId: 1300,
                mobileName: 'Nokia',
                mobileCost: 2500,
                mobileType: ''
            },
            { mobileId: 5130,
                mobileName: 'Nokia',
                mobileCost: 5300,
                mobileType: ''
            },
            { mobileId: 5,
                mobileName: 'Redmi',
                mobileCost: 9999,
                mobileType: ''
            }
        ];
    }
    AppComponent.prototype.ngOnInit = function () {
        for (var i = 0; i < 3; i++) {
            if (this.mobiles[i].mobileCost < 9999)
                this.mobiles[i].mobileType = this._service1.gettype();
            else
                this.mobiles[i].mobileType = this._service2.gettype();
        }
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: './app.component.html',
        providers: [basic_service_1.basicService, smart_service_1.smartService]
    }),
    __metadata("design:paramtypes", [basic_service_1.basicService, smart_service_1.smartService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map