import { Component } from '@angular/core';
import { basicService } from './basic.service';
import { smartService } from './smart.service';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  providers: [ basicService, smartService ]
})
export class AppComponent  { 
  mobiles= [
    { mobileId: 1300,
      mobileName: 'Nokia',
      mobileCost: 2500,
      mobileType: ''
    },
    { mobileId: 5130,
      mobileName: 'Nokia',
      mobileCost: 5300,
      mobileType: ''
    },
    { mobileId: 5,
      mobileName: 'Redmi',
      mobileCost: 9999,
      mobileType: ''
    }
  ]
  constructor(private _service1: basicService, private _service2: smartService){

  }
  ngOnInit(){
    for(let i=0;i<3;i++){
      if( this.mobiles[i].mobileCost<9999)
        this.mobiles[i].mobileType=this._service1.gettype();
      else
      this.mobiles[i].mobileType=this._service2.gettype();
    }
  }
}
