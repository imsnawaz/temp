import { Injectable } from '@angular/core'

@Injectable()

export class basicService{
    gettype(){
        return 'Basic'
    }
}